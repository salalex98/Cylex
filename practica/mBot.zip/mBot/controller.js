class Controller {
	constructor() {
		this.init();
	}

	init() {
		this.labirint = new Labirint();
		this.mBot = new Bot(this.labirint);
	}
}

new Controller();